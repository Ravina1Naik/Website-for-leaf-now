
module.exports = {
    MONGO : {
        URI : 'YOUR-MONGO-URI'
    },
    GMAIL : {
        EMAIL_ID : 'YOUR-EMAIL-ID',
        EMAIL_PASS : 'YOUR-EMAIL-PASSWORD',
        EMAIL_SECRET : 'EMAIL-SECRET'   //RANDOM
    },
    GOOGLE : {
        CLIENT_ID : 'GOOGLE-0AUTH-CLIENT-ID',
        CLIENT_SECRET : 'GOOGLE-0AUTH-CLIENT-SECRET'
    },
    SESSION : {
        COOKIE_KEY : 'COOKIE-KEY'   //RANDOM
    },
    baseUrl :  'BASE-URL'
} 
